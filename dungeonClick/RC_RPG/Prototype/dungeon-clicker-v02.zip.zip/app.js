// Donjon Clicker V0.2 - Logique principale

// Données de base du jeu
const gameData = {
  characters: {
    "Guerrier": {
      baseHp: 200,
      baseAttack: 10,
      baseAttackPrecision: 50,
      baseAttackSpe: 15,
      baseAttackSpePrecision: 60,
      attackSpeEffect: "freeze",
      baseHeal: 0.10,
      level: 1,
      upgradeCostBase: 10,
      description: "Coup d'épée + inflige gel"
    },
    "Archer": {
      baseHp: 100,
      baseAttack: 15,
      baseAttackPrecision: 60,
      baseAttackSpe: 20,
      baseAttackSpePrecision: 60,
      attackSpeEffect: "poison_5",
      baseHeal: 0.10,
      level: 1,
      upgradeCostBase: 10,
      description: "Flèche empoisonnée + poison 5"
    },
    "Mage": {
      baseHp: 120,
      baseAttack: 10,
      baseAttackPrecision: 70,
      baseAttackSpe: 15,
      baseAttackSpePrecision: 80,
      attackSpeEffect: "burn_5",
      baseHeal: 0.20,
      level: 1,
      upgradeCostBase: 10,
      description: "Boule de feu + inflige brûlure 5"
    }
  },
  enemies: {
    "LoupSolitaire": {
      name: "Loup solitaire",
      hp: 120,
      attack: 20,
      attackPrecision: 60,
      attackSpe: 25,
      attackSpePrecision: 65,
      abilities: ["ATK", "ATK_SPE", "FOCUS"],
      type: "classic",
      rewards: { dungeonClicks: 2, materials: ["Croc de loup"] }
    },
    "Sanglier": {
      name: "Sanglier",
      hp: 220,
      attack: 10,
      attackPrecision: 60,
      abilities: ["ATK", "FOCUS", "DEF"],
      type: "classic",
      rewards: { dungeonClicks: 3, materials: ["Cuir de sanglier"] }
    },
    "Boss1": {
      name: "Chef des Loups",
      hp: 400,
      attack: 25,
      attackPrecision: 65,
      attackSpe: 35,
      attackSpePrecision: 70,
      abilities: ["ATK", "ATK_SPE", "FOCUS", "DEF"],
      type: "boss",
      rewards: { dungeonClicks: 10, improvementClicks: 5, materials: ["Essence de chef", "Croc alpha"] }
    }
  }
};

// Cooldowns V3
const COOLDOWNS_V3 = {
  "ATK": 2,
  "DEF": 2,
  "FOCUS": 2,
  "HEAL": 2,
  "ATK_SPE": 3
};

// État global du jeu (persistant entre les resets de donjon)
let persistentState = {
  improvementClicks: 0,
  materials: {},
  characters: {
    "Guerrier": { level: 1 },
    "Archer": { level: 1 },
    "Mage": { level: 1 }
  },
  equipment: {},
  quests: {
    1: { completed: false, progress: 0, target: 3 },
    2: { completed: false, progress: 0, target: 1 }
  },
  questsCompleted: 0,
  combatsWon: 0
};

// État temporaire du donjon (reset à chaque mort)
let dungeonState = {
  currentRoom: 1,
  dungeonClicks: 30,
  playerCharacter: null,
  playerHp: 0,
  playerMaxHp: 0,
  team: [],
  currentEnemy: null,
  combatTurn: 1,
  selectedAction: null,
  cooldowns: {},
  inCombat: false
};

// Classe Character pour le combat
class Character {
  constructor(name, classType, isPlayer = false, isAlly = false) {
    this.name = name;
    this.classType = classType;
    this.isPlayer = isPlayer;
    this.isAlly = isAlly;
    this.id = Math.random().toString(36).substr(2, 9);
    
    if (gameData.characters[classType]) {
      const charData = gameData.characters[classType];
      const level = persistentState.characters[classType].level;
      
      // Calculs avec bonus de niveau CA + équipements
      this.maxHp = this.calculateHp(charData, level, isPlayer);
      this.currentHp = this.maxHp;
      this.attack = this.calculateAttack(charData, level, isPlayer);
      this.attackPrecision = charData.baseAttackPrecision + (isPlayer ? this.getEquipmentBonus('attackPrecision') : 0);
      this.attackSpe = charData.baseAttackSpe;
      this.attackSpePrecision = charData.baseAttackSpePrecision;
      this.attackSpeEffect = charData.attackSpeEffect;
      this.healPercent = charData.baseHeal;
    } else if (gameData.enemies[classType]) {
      const enemyData = gameData.enemies[classType];
      this.name = enemyData.name;
      this.maxHp = enemyData.hp;
      this.currentHp = this.maxHp;
      this.attack = enemyData.attack;
      this.attackPrecision = enemyData.attackPrecision;
      this.attackSpe = enemyData.attackSpe;
      this.attackSpePrecision = enemyData.attackSpePrecision;
      this.attackSpeEffect = enemyData.attackSpeEffect;
      this.abilities = enemyData.abilities;
      this.healPercent = 0.15;
    }
    
    this.cooldowns = {};
    this.statusEffects = {};
  }
  
  calculateHp(charData, level, isPlayer) {
    let hp = charData.baseHp + ((level - 1) * 20); // Bonus CA
    if (isPlayer) {
      hp += this.getEquipmentBonus('hp'); // Bonus équipement
    } else {
      hp = Math.floor(hp * 0.8); // Alliés -20%
    }
    return hp;
  }
  
  calculateAttack(charData, level, isPlayer) {
    let attack = charData.baseAttack + ((level - 1) * 2); // Bonus CA
    if (isPlayer) {
      attack += this.getEquipmentBonus('attack'); // Bonus équipement
    } else {
      attack = Math.floor(attack * 0.8); // Alliés -20%
    }
    return attack;
  }
  
  getEquipmentBonus(stat) {
    // Simuler les bonus d'équipement
    return persistentState.equipment[stat] || 0;
  }
  
  isAlive() {
    return this.currentHp > 0;
  }
  
  takeDamage(damage) {
    this.currentHp = Math.max(0, this.currentHp - damage);
  }
  
  heal(amount) {
    this.currentHp = Math.min(this.maxHp, this.currentHp + amount);
  }
  
  hasStatusEffect(effect) {
    return this.statusEffects[effect] && this.statusEffects[effect] > 0;
  }
  
  addStatusEffect(effect, duration) {
    this.statusEffects[effect] = duration;
  }
  
  removeStatusEffect(effect) {
    delete this.statusEffects[effect];
  }
  
  updateStatusEffects() {
    Object.keys(this.statusEffects).forEach(effect => {
      if (this.statusEffects[effect] > 0) {
        this.statusEffects[effect]--;
        if (this.statusEffects[effect] <= 0) {
          this.removeStatusEffect(effect);
        }
      }
    });
  }
  
  updateCooldowns() {
    Object.keys(this.cooldowns).forEach(action => {
      if (this.cooldowns[action] > 0) {
        this.cooldowns[action]--;
      }
    });
  }
  
  canUseAction(action) {
    return !this.cooldowns[action] || this.cooldowns[action] <= 0;
  }
}

// Initialisation du jeu
document.addEventListener('DOMContentLoaded', function() {
  loadGame();
  initializeEventListeners();
  showScreen('main-menu');
  updateMainMenuStats();
});

function loadGame() {
  const saved = localStorage.getItem('dungeonClickerV02');
  if (saved) {
    try {
      const data = JSON.parse(saved);
      persistentState = { ...persistentState, ...data };
    } catch (e) {
      console.log('Erreur de chargement, nouveau jeu');
    }
  }
}

function saveGame() {
  localStorage.setItem('dungeonClickerV02', JSON.stringify(persistentState));
}

function initializeEventListeners() {
  // Menu principal
  document.querySelectorAll('.menu-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const screen = this.dataset.screen;
      showScreen(screen);
      if (screen === 'dungeon-entry') {
        updateCharacterSelection();
      } else if (screen === 'tavern') {
        updateTavernDisplay();
      } else if (screen === 'forge') {
        updateForgeDisplay();
      } else if (screen === 'quests') {
        updateQuestsDisplay();
      }
    });
  });
  
  // Boutons retour
  document.querySelectorAll('.back-btn, #back-to-menu').forEach(btn => {
    btn.addEventListener('click', function() {
      showScreen('main-menu');
      updateMainMenuStats();
    });
  });
  
  // Sélection de personnage
  document.querySelectorAll('.select-character-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const characterCard = this.closest('.character-card');
      const selectedClass = characterCard.dataset.class;
      startDungeonWithCharacter(selectedClass);
    });
  });
  
  // Actions du donjon
  document.getElementById('start-combat')?.addEventListener('click', startCombat);
  document.getElementById('search-room')?.addEventListener('click', searchRoom);
  document.getElementById('skip-search')?.addEventListener('click', nextRoom);
  document.getElementById('skip-merchant')?.addEventListener('click', nextRoom);
  document.getElementById('flee-dungeon')?.addEventListener('click', fleeDungeon);
  
  // Combat
  document.querySelectorAll('.action-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const action = this.dataset.action;
      executePlayerAction(action);
    });
  });
  
  // Marchant
  document.querySelectorAll('.buy-item').forEach(btn => {
    btn.addEventListener('click', function() {
      const item = this.dataset.item;
      const cost = parseInt(this.dataset.cost);
      buyMerchantItem(item, cost);
    });
  });
  
  // Modales
  document.getElementById('respawn-btn')?.addEventListener('click', function() {
    hideModal('death-modal');
    resetAfterDeath();
  });
  
  document.getElementById('continue-dungeon')?.addEventListener('click', function() {
    hideModal('combat-end-modal');
    nextRoom();
  });
  
  document.getElementById('exit-dungeon')?.addEventListener('click', function() {
    hideModal('combat-end-modal');
    exitDungeon();
  });
  
  // Taverne
  document.querySelectorAll('.upgrade-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const section = this.closest('.upgrade-section');
      const characterClass = section.dataset.class;
      const cost = parseInt(this.dataset.cost);
      upgradeCharacter(characterClass, cost);
    });
  });
  
  // Forge
  document.querySelectorAll('.craft-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const recipe = this.closest('.recipe').dataset.recipe;
      craftItem(recipe);
    });
  });
  
  // Quêtes
  document.querySelectorAll('.claim-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      const questCard = this.closest('.quest-card');
      const questId = parseInt(questCard.dataset.quest);
      claimQuest(questId);
    });
  });
}

function showScreen(screenId) {
  document.querySelectorAll('.screen').forEach(screen => {
    screen.classList.add('hidden');
  });
  document.getElementById(screenId).classList.remove('hidden');
}

function showModal(modalId) {
  document.getElementById(modalId).classList.remove('hidden');
}

function hideModal(modalId) {
  document.getElementById(modalId).classList.add('hidden');
}

function updateMainMenuStats() {
  document.getElementById('main-ca').textContent = persistentState.improvementClicks;
  const totalMaterials = Object.values(persistentState.materials).reduce((sum, count) => sum + count, 0);
  document.getElementById('main-materials').textContent = totalMaterials;
}

function updateCharacterSelection() {
  document.querySelectorAll('.character-card').forEach(card => {
    const characterClass = card.dataset.class;
    const charData = gameData.characters[characterClass];
    const level = persistentState.characters[characterClass].level;
    
    // Calculer les stats avec bonus
    const hp = charData.baseHp + ((level - 1) * 20) + (persistentState.equipment.hp || 0);
    const attack = charData.baseAttack + ((level - 1) * 2) + (persistentState.equipment.attack || 0);
    const precision = charData.baseAttackPrecision + (persistentState.equipment.attackPrecision || 0);
    
    card.querySelector('.hp-value').textContent = hp;
    card.querySelector('.attack-value').textContent = attack;
    card.querySelector('.precision-value').textContent = precision;
    card.querySelector('.attack-spe-value').textContent = charData.baseAttackSpe;
    card.querySelector('.precision-spe-value').textContent = charData.baseAttackSpePrecision;
    card.querySelector('.heal-value').textContent = Math.floor(charData.baseHeal * 100);
    card.querySelector('.level-value').textContent = level;
  });
}

function startDungeonWithCharacter(characterClass) {
  // Réinitialiser l'état du donjon
  dungeonState = {
    currentRoom: 1,
    dungeonClicks: 30,
    playerCharacter: characterClass,
    playerHp: 0,
    playerMaxHp: 0,
    team: [],
    currentEnemy: null,
    combatTurn: 1,
    selectedAction: null,
    cooldowns: {},
    inCombat: false
  };
  
  // Créer le personnage joueur avec stats complètes
  const player = new Character("Vous", characterClass, true, true);
  dungeonState.playerHp = player.maxHp;
  dungeonState.playerMaxHp = player.maxHp;
  dungeonState.team = [player];
  
  showScreen('dungeon-exploration');
  generateRoom();
}

function generateRoom() {
  const roomNumber = dungeonState.currentRoom;
  updateDungeonHeader();
  
  // Cacher tous les types de pièces
  document.querySelectorAll('.room-type').forEach(room => {
    room.classList.add('hidden');
  });
  
  let roomType;
  if (roomNumber === 21) {
    roomType = 'boss';
  } else if (roomNumber % 7 === 0) {
    roomType = 'merchant';
  } else if (roomNumber % 3 === 0) {
    roomType = 'search';
  } else {
    roomType = 'combat';
  }
  
  if (roomType === 'combat' || roomType === 'boss') {
    setupCombatRoom(roomType === 'boss');
  } else if (roomType === 'search') {
    document.getElementById('room-search').classList.remove('hidden');
  } else if (roomType === 'merchant') {
    document.getElementById('room-merchant').classList.remove('hidden');
  }
}

function setupCombatRoom(isBoss = false) {
  document.getElementById('room-combat').classList.remove('hidden');
  
  // Configurer les options d'alliés selon le personnage principal
  const allyOptions = document.querySelectorAll('.ally-option');
  allyOptions.forEach(option => {
    const checkbox = option.querySelector('.ally-checkbox');
    const allyClass = checkbox.dataset.class;
    
    if (allyClass === dungeonState.playerCharacter) {
      option.style.display = 'none';
    } else {
      option.style.display = 'flex';
      checkbox.checked = false;
    }
  });
}

function startCombat() {
  // Vérifier les alliés sélectionnés
  const selectedAllies = [];
  const allyCheckboxes = document.querySelectorAll('.ally-checkbox:checked');
  let allyCost = 0;
  
  allyCheckboxes.forEach(checkbox => {
    const allyClass = checkbox.dataset.class;
    const cost = parseInt(checkbox.dataset.cost);
    allyCost += cost;
    selectedAllies.push(allyClass);
  });
  
  if (allyCost > dungeonState.dungeonClicks) {
    alert('Pas assez de CD pour ces alliés !');
    return;
  }
  
  // Déduire le coût des alliés
  dungeonState.dungeonClicks -= allyCost;
  
  // Ajouter les alliés à l'équipe
  selectedAllies.forEach(allyClass => {
    const ally = new Character(`${allyClass} Allié`, allyClass, false, true);
    dungeonState.team.push(ally);
  });
  
  // Générer l'ennemi
  const enemyTypes = Object.keys(gameData.enemies);
  const randomEnemyType = enemyTypes[Math.floor(Math.random() * enemyTypes.length)];
  dungeonState.currentEnemy = new Character("Ennemi", randomEnemyType, false, false);
  
  // Réinitialiser l'état de combat
  dungeonState.combatTurn = 1;
  dungeonState.selectedAction = null;
  dungeonState.inCombat = true;
  
  // Réinitialiser les cooldowns
  dungeonState.team.forEach(char => {
    char.cooldowns = {};
    char.statusEffects = {};
  });
  dungeonState.currentEnemy.cooldowns = {};
  dungeonState.currentEnemy.statusEffects = {};
  
  showScreen('combat-screen');
  updateCombatDisplay();
  addLogEntry(`Combat contre ${dungeonState.currentEnemy.name} !`, 'turn');
  
  // Vider le log précédent
  document.getElementById('combat-log').innerHTML = '';
}

function executePlayerAction(action) {
  const player = dungeonState.team[0];
  
  // Vérifier si l'action est disponible
  if (!player.canUseAction(action)) {
    addLogEntry(`${action} est en cooldown pour ${player.cooldowns[action]} tour(s)`, 'miss');
    return;
  }
  
  // Vérifier si assez de CD
  if (dungeonState.dungeonClicks <= 0) {
    checkDeath('cd');
    return;
  }
  
  // Coûter 1 CD
  dungeonState.dungeonClicks--;
  
  // Exécuter l'action
  let target = null;
  if (action === 'ATK' || action === 'ATK_SPE') {
    target = dungeonState.currentEnemy;
  } else if (action === 'HEAL') {
    target = player; // Auto-ciblage pour simplifier
  } else {
    target = player;
  }
  
  performAction(player, action, target);
  
  // Appliquer le cooldown V3
  if (COOLDOWNS_V3[action]) {
    player.cooldowns[action] = COOLDOWNS_V3[action];
  }
  
  // Passer au tour suivant
  endPlayerTurn();
}

function performAction(character, action, target) {
  switch (action) {
    case 'ATK':
      performAttack(character, target, false);
      break;
    case 'ATK_SPE':
      performAttack(character, target, true);
      break;
    case 'FOCUS':
      character.addStatusEffect('focus', 3);
      addLogEntry(`${character.name} se concentre (+15% précision pour 3 tours)`, 'effect');
      break;
    case 'DEF':
      character.addStatusEffect('defense', 3);
      addLogEntry(`${character.name} se met en défense (-15 dégâts pour 3 tours)`, 'effect');
      break;
    case 'HEAL':
      const healAmount = Math.floor(target.maxHp * character.healPercent);
      const oldHp = target.currentHp;
      target.heal(healAmount);
      const actualHeal = target.currentHp - oldHp;
      if (target.hasStatusEffect('poison')) {
        target.removeStatusEffect('poison');
        addLogEntry(`${target.name} n'est plus empoisonné`, 'heal');
      }
      addLogEntry(`${character.name} soigne ${target.name} de ${actualHeal} PV`, 'heal');
      animateCharacter(target.id, 'heal');
      break;
  }
  updateCombatDisplay();
}

function performAttack(attacker, target, isSpecial = false) {
  let precision = isSpecial ? attacker.attackSpePrecision : attacker.attackPrecision;
  
  if (attacker.hasStatusEffect('focus')) {
    precision += 15;
  }
  
  const roll = Math.random() * 100;
  if (roll > precision) {
    addLogEntry(`${attacker.name} rate son attaque contre ${target.name}`, 'miss');
    return;
  }
  
  let damage = isSpecial ? attacker.attackSpe : attacker.attack;
  
  if (target.hasStatusEffect('defense')) {
    damage = Math.max(1, damage - 15);
  }
  
  target.takeDamage(damage);
  addLogEntry(`${attacker.name} inflige ${damage} dégâts à ${target.name}`, 'damage');
  
  if (isSpecial && attacker.attackSpeEffect) {
    applyStatusEffect(target, attacker.attackSpeEffect);
  }
  
  animateCharacter(target.id, 'damage');
}

function applyStatusEffect(target, effectString) {
  const [effect, value] = effectString.split('_');
  
  switch (effect) {
    case 'freeze':
      target.addStatusEffect('frozen', 1);
      addLogEntry(`${target.name} est gelé`, 'effect');
      break;
    case 'burn':
      target.addStatusEffect('burn', parseInt(value));
      addLogEntry(`${target.name} brûle (${value} tours)`, 'effect');
      break;
    case 'poison':
      target.addStatusEffect('poison', parseInt(value));
      addLogEntry(`${target.name} est empoisonné (${value} dégâts par tour)`, 'effect');
      break;
  }
}

function endPlayerTurn() {
  // Tours des alliés IA
  for (let i = 1; i < dungeonState.team.length; i++) {
    const ally = dungeonState.team[i];
    if (ally.isAlive() && !ally.hasStatusEffect('frozen')) {
      performAITurn(ally, true);
    }
  }
  
  // Tour de l'ennemi
  if (dungeonState.currentEnemy.isAlive()) {
    if (!dungeonState.currentEnemy.hasStatusEffect('frozen')) {
      performAITurn(dungeonState.currentEnemy, false);
    } else {
      addLogEntry(`${dungeonState.currentEnemy.name} est gelé et ne peut pas jouer`, 'effect');
    }
  }
  
  // Appliquer les effets de statut
  processStatusEffects();
  
  // Vérifier la fin de combat
  if (checkCombatEnd()) {
    return;
  }
  
  // Nouveau tour du joueur - décrémenter cooldowns
  const player = dungeonState.team[0];
  if (player && player.isAlive()) {
    player.updateCooldowns();
    
    // Mettre à jour les PV du joueur
    dungeonState.playerHp = player.currentHp;
    
    // Vérifier mort par PV
    if (dungeonState.playerHp <= 0) {
      checkDeath('hp');
      return;
    }
  }
  
  dungeonState.combatTurn++;
  updateCombatDisplay();
  addLogEntry(`--- Tour ${dungeonState.combatTurn} ---`, 'turn');
}

function performAITurn(character, isAlly) {
  const availableActions = character.abilities || ['ATK', 'ATK_SPE', 'FOCUS', 'DEF', 'HEAL'];
  
  if (availableActions.length === 0) {
    addLogEntry(`${character.name} ne peut pas agir`, 'miss');
    return;
  }
  
  let selectedAction = chooseAIAction(character, availableActions, isAlly);
  let target = null;
  
  if (selectedAction === 'ATK' || selectedAction === 'ATK_SPE') {
    if (isAlly) {
      target = dungeonState.currentEnemy;
    } else {
      const aliveAllies = dungeonState.team.filter(char => char.isAlive());
      target = aliveAllies[Math.floor(Math.random() * aliveAllies.length)];
    }
  } else if (selectedAction === 'HEAL') {
    if (isAlly) {
      const damagedAllies = dungeonState.team.filter(char => char.isAlive() && char.currentHp < char.maxHp);
      target = damagedAllies.length > 0 ? damagedAllies[0] : character;
    } else {
      target = character;
    }
  } else {
    target = character;
  }
  
  if (target) {
    performAction(character, selectedAction, target);
  }
}

function chooseAIAction(character, availableActions, isAlly) {
  if (character.currentHp < character.maxHp * 0.3 && availableActions.includes('HEAL')) {
    return 'HEAL';
  }
  
  if (Math.random() < 0.2 && !character.hasStatusEffect('focus') && availableActions.includes('FOCUS')) {
    return 'FOCUS';
  }
  
  if (Math.random() < 0.15 && !character.hasStatusEffect('defense') && availableActions.includes('DEF')) {
    return 'DEF';
  }
  
  if (availableActions.includes('ATK_SPE') && Math.random() < 0.6) {
    return 'ATK_SPE';
  }
  
  if (availableActions.includes('ATK')) {
    return 'ATK';
  }
  
  return availableActions[Math.floor(Math.random() * availableActions.length)];
}

function processStatusEffects() {
  const allCharacters = [...dungeonState.team, dungeonState.currentEnemy];
  
  allCharacters.forEach(character => {
    if (!character.isAlive()) return;
    
    if (character.hasStatusEffect('burn')) {
      const burnDamage = character.statusEffects.burn;
      character.takeDamage(burnDamage);
      addLogEntry(`${character.name} subit ${burnDamage} dégâts de brûlure`, 'damage');
      animateCharacter(character.id, 'damage');
    }
    
    if (character.hasStatusEffect('poison')) {
      const poisonDamage = 5;
      character.takeDamage(poisonDamage);
      addLogEntry(`${character.name} subit ${poisonDamage} dégâts de poison`, 'damage');
      animateCharacter(character.id, 'damage');
    }
    
    character.updateStatusEffects();
  });
  
  updateCombatDisplay();
}

function checkCombatEnd() {
  const aliveAllies = dungeonState.team.filter(char => char.isAlive());
  const enemyAlive = dungeonState.currentEnemy.isAlive();
  
  if (aliveAllies.length === 0) {
    endCombat(false);
    return true;
  } else if (!enemyAlive) {
    endCombat(true);
    return true;
  }
  
  return false;
}

function endCombat(victory) {
  dungeonState.inCombat = false;
  
  const resultTitle = document.getElementById('combat-result-title');
  const resultContent = document.getElementById('combat-result-content');
  
  if (victory) {
    resultTitle.textContent = 'Victoire !';
    resultTitle.className = 'victory';
    
    const rewards = dungeonState.currentEnemy.classType ? 
      gameData.enemies[dungeonState.currentEnemy.classType].rewards : 
      { dungeonClicks: 2 };
    
    dungeonState.dungeonClicks += rewards.dungeonClicks || 2;
    
    if (rewards.improvementClicks) {
      persistentState.improvementClicks += rewards.improvementClicks;
    }
    
    if (rewards.materials) {
      rewards.materials.forEach(material => {
        persistentState.materials[material] = (persistentState.materials[material] || 0) + 1;
      });
    }
    
    persistentState.combatsWon++;
    updateQuest(1, 'combat');
    
    resultContent.innerHTML = `
      <p>Vous avez vaincu ${dungeonState.currentEnemy.name} !</p>
      <p>+${rewards.dungeonClicks || 2} CD</p>
      ${rewards.improvementClicks ? `<p>+${rewards.improvementClicks} CA</p>` : ''}
    `;
    
    // Guérir légèrement l'équipe après victoire
    dungeonState.team.forEach(char => {
      if (char.isAlive()) {
        const healAmount = Math.floor(char.maxHp * 0.1);
        char.heal(healAmount);
        if (char.isPlayer) {
          dungeonState.playerHp = char.currentHp;
        }
      }
    });
    
  } else {
    resultTitle.textContent = 'Défaite...';
    resultTitle.className = 'defeat';
    resultContent.innerHTML = `
      <p>${dungeonState.currentEnemy.name} a eu raison de votre équipe.</p>
    `;
  }
  
  saveGame();
  showModal('combat-end-modal');
}

function checkDeath(reason) {
  let deathMessage = '';
  if (reason === 'hp') {
    deathMessage = 'Vos PV sont tombés à 0 !';
  } else if (reason === 'cd') {
    deathMessage = 'Vous n\'avez plus de CD !';
  }
  
  document.getElementById('death-reason').innerHTML = `<p>${deathMessage}</p>`;
  showModal('death-modal');
}

function resetAfterDeath() {
  // Reset uniquement le donjon, garder les améliorations
  dungeonState = {
    currentRoom: 1,
    dungeonClicks: 30,
    playerCharacter: null,
    playerHp: 0,
    playerMaxHp: 0,
    team: [],
    currentEnemy: null,
    combatTurn: 1,
    selectedAction: null,
    cooldowns: {},
    inCombat: false
  };
  
  showScreen('main-menu');
  updateMainMenuStats();
}

function nextRoom() {
  dungeonState.currentRoom++;
  if (dungeonState.currentRoom > 21) {
    // Finir le donjon
    alert('Félicitations ! Vous avez terminé le donjon !');
    exitDungeon();
  } else {
    // Supprimer les alliés temporaires avant la prochaine pièce
    dungeonState.team = [dungeonState.team[0]]; // Garder seulement le joueur
    showScreen('dungeon-exploration');
    generateRoom();
  }
}

function exitDungeon() {
  showScreen('main-menu');
  updateMainMenuStats();
  saveGame();
}

function fleeDungeon() {
  if (confirm('Êtes-vous sûr de vouloir fuir le donjon ? Votre progression sera perdue.')) {
    exitDungeon();
  }
}

function searchRoom() {
  if (dungeonState.dungeonClicks >= 1) {
    dungeonState.dungeonClicks--;
    
    // Chance de trouver quelque chose
    const roll = Math.random();
    if (roll < 0.5) {
      const materials = ['Fer', 'Cuir', 'Bois'];
      const foundMaterial = materials[Math.floor(Math.random() * materials.length)];
      persistentState.materials[foundMaterial] = (persistentState.materials[foundMaterial] || 0) + 1;
      alert(`Vous avez trouvé: ${foundMaterial} !`);
    } else {
      alert('Vous ne trouvez rien d\'utile...');
    }
    
    nextRoom();
  } else {
    alert('Pas assez de CD !');
  }
}

function buyMerchantItem(item, cost) {
  if (dungeonState.dungeonClicks >= cost) {
    dungeonState.dungeonClicks -= cost;
    
    if (item === 'health') {
      const player = dungeonState.team[0];
      if (player) {
        player.heal(50);
        dungeonState.playerHp = player.currentHp;
        alert('Vous récupérez 50 PV !');
      }
    } else if (item === 'cd') {
      dungeonState.dungeonClicks += 10;
      alert('Vous gagnez 10 CD !');
    }
    
    updateDungeonHeader();
  } else {
    alert('Pas assez de CD !');
  }
}

function updateDungeonHeader() {
  document.getElementById('current-room').textContent = dungeonState.currentRoom;
  document.getElementById('dungeon-cd').textContent = dungeonState.dungeonClicks;
  document.getElementById('player-hp').textContent = dungeonState.playerHp;
  document.getElementById('player-max-hp').textContent = dungeonState.playerMaxHp;
  document.getElementById('current-character').textContent = dungeonState.playerCharacter || 'Aucun';
}

function updateCombatDisplay() {
  document.getElementById('combat-cd').textContent = dungeonState.dungeonClicks;
  document.getElementById('combat-turn').textContent = dungeonState.combatTurn;
  document.getElementById('combat-room').textContent = dungeonState.currentRoom;
  
  updateCharactersList('allies-list', dungeonState.team);
  updateCharactersList('enemies-list', [dungeonState.currentEnemy]);
  updateActionButtons();
}

function updateCharactersList(containerId, characters) {
  const container = document.getElementById(containerId);
  container.innerHTML = '';
  
  characters.forEach(character => {
    const characterDiv = document.createElement('div');
    characterDiv.className = `character-combat-card ${character.isAlly ? 'ally' : 'enemy'}`;
    characterDiv.id = `char_${character.id}`;
    
    if (!character.isAlive()) {
      characterDiv.classList.add('dead');
    }
    
    if (character.hasStatusEffect('frozen')) {
      characterDiv.classList.add('frozen');
    }
    
    const hpPercentage = (character.currentHp / character.maxHp) * 100;
    
    characterDiv.innerHTML = `
      <div class="character-name">${character.name}</div>
      <div class="character-hp">
        <div class="hp-bar-container">
          <div class="hp-bar ${character.isAlly ? 'ally' : 'enemy'}" 
               style="width: ${hpPercentage}%"></div>
        </div>
        <div class="hp-text">${character.currentHp}/${character.maxHp} PV</div>
      </div>
      <div class="character-effects">
        ${getStatusEffectsHTML(character)}
      </div>
    `;
    
    container.appendChild(characterDiv);
  });
}

function getStatusEffectsHTML(character) {
  let html = '';
  
  Object.keys(character.statusEffects).forEach(effect => {
    const duration = character.statusEffects[effect];
    if (duration > 0) {
      let effectClass = 'effect-' + effect;
      let effectText = '';
      
      switch (effect) {
        case 'frozen':
          effectText = 'Gelé';
          effectClass = 'effect-freeze';
          break;
        case 'burn':
          effectText = `Brûlure (${duration})`;
          break;
        case 'poison':
          effectText = 'Poison';
          break;
        case 'focus':
          effectText = `Focus (${duration})`;
          break;
        case 'defense':
          effectText = `Défense (${duration})`;
          break;
      }
      
      html += `<span class="effect-icon ${effectClass}">${effectText}</span>`;
    }
  });
  
  return html;
}

function updateActionButtons() {
  const player = dungeonState.team[0];
  if (!player || !player.isAlive()) return;
  
  document.querySelectorAll('.action-btn').forEach(btn => {
    const action = btn.dataset.action;
    const cooldown = player.cooldowns[action] || 0;
    const cooldownSpan = btn.querySelector('.action-cooldown');
    
    if (cooldown > 0) {
      btn.disabled = true;
      cooldownSpan.textContent = `Cooldown: ${cooldown} tour(s)`;
    } else {
      btn.disabled = false;
      cooldownSpan.textContent = '';
    }
    
    if (player.hasStatusEffect('frozen')) {
      btn.disabled = true;
      if (cooldown <= 0) {
        cooldownSpan.textContent = 'Gelé';
      }
    }
    
    if (dungeonState.dungeonClicks <= 0) {
      btn.disabled = true;
      if (cooldown <= 0 && !player.hasStatusEffect('frozen')) {
        cooldownSpan.textContent = 'Pas de CD';
      }
    }
  });
}

function addLogEntry(message, type = 'normal') {
  const log = document.getElementById('combat-log');
  const entry = document.createElement('div');
  entry.className = `log-entry ${type}`;
  entry.textContent = message;
  log.appendChild(entry);
  log.scrollTop = log.scrollHeight;
  
  // Limiter le nombre d'entrées pour éviter l'accumulation
  while (log.children.length > 50) {
    log.removeChild(log.firstChild);
  }
}

function animateCharacter(characterId, animationType) {
  const element = document.getElementById(`char_${characterId}`);
  if (element) {
    element.classList.add(`${animationType}-animation`);
    setTimeout(() => {
      element.classList.remove(`${animationType}-animation`);
    }, 500);
  }
}

// Fonctions de gestion (Taverne, Forge, Quêtes)
function updateTavernDisplay() {
  document.querySelectorAll('.upgrade-section').forEach(section => {
    const characterClass = section.dataset.class;
    const level = persistentState.characters[characterClass].level;
    const cost = gameData.characters[characterClass].upgradeCostBase * level;
    
    section.querySelector('.current-level').textContent = level;
    const btn = section.querySelector('.upgrade-btn');
    btn.dataset.cost = cost;
    btn.textContent = `Améliorer (${cost} CA)`;
    btn.disabled = persistentState.improvementClicks < cost;
  });
}

function upgradeCharacter(characterClass, cost) {
  if (persistentState.improvementClicks >= cost) {
    persistentState.improvementClicks -= cost;
    persistentState.characters[characterClass].level++;
    
    updateQuest(2, 'upgrade');
    saveGame();
    updateTavernDisplay();
    alert(`${characterClass} amélioré au niveau ${persistentState.characters[characterClass].level} !`);
  }
}

function updateForgeDisplay() {
  const materialsList = document.getElementById('materials-list');
  materialsList.innerHTML = '';
  
  Object.keys(persistentState.materials).forEach(material => {
    const count = persistentState.materials[material];
    if (count > 0) {
      const div = document.createElement('div');
      div.className = 'material-item';
      div.innerHTML = `
        <div>${material}</div>
        <div class="material-count">${count}</div>
      `;
      materialsList.appendChild(div);
    }
  });
  
  if (Object.keys(persistentState.materials).length === 0) {
    materialsList.innerHTML = '<p>Aucun matériau trouvé. Explorez le donjon pour en obtenir !</p>';
  }
}

function craftItem(recipe) {
  // Simuler le craft d'une épée
  if (recipe === 'sword') {
    const hasIron = (persistentState.materials['Fer'] || 0) >= 3;
    const hasLeather = (persistentState.materials['Cuir'] || 0) >= 1;
    const hasCA = persistentState.improvementClicks >= 5;
    
    if (hasIron && hasLeather && hasCA) {
      persistentState.materials['Fer'] -= 3;
      persistentState.materials['Cuir'] -= 1;
      persistentState.improvementClicks -= 5;
      persistentState.equipment.attack = (persistentState.equipment.attack || 0) + 5;
      
      saveGame();
      updateForgeDisplay();
      alert('Épée en fer créée ! +5 Attaque');
    } else {
      alert('Matériaux insuffisants ! Besoin de: 3 Fer, 1 Cuir, 5 CA');
    }
  }
}

function updateQuestsDisplay() {
  document.querySelectorAll('.quest-card').forEach(card => {
    const questId = parseInt(card.dataset.quest);
    const quest = persistentState.quests[questId];
    
    card.querySelector('.progress-value').textContent = quest.progress;
    const claimBtn = card.querySelector('.claim-btn');
    
    if (quest.progress >= quest.target && !quest.completed) {
      claimBtn.classList.remove('hidden');
    } else {
      claimBtn.classList.add('hidden');
    }
    
    if (quest.completed) {
      card.style.opacity = '0.6';
      const title = card.querySelector('h3');
      if (!title.textContent.includes('✓')) {
        title.textContent += ' ✓';
      }
    }
  });
}

function updateQuest(questId, type) {
  const quest = persistentState.quests[questId];
  if (!quest || quest.completed) return;
  
  if (questId === 1 && type === 'combat') {
    quest.progress = Math.min(quest.target, persistentState.combatsWon);
  } else if (questId === 2 && type === 'upgrade') {
    const maxLevel = Math.max(
      persistentState.characters.Guerrier.level,
      persistentState.characters.Archer.level,
      persistentState.characters.Mage.level
    );
    quest.progress = maxLevel >= 2 ? 1 : 0;
  }
}

function claimQuest(questId) {
  const quest = persistentState.quests[questId];
  if (quest && quest.progress >= quest.target && !quest.completed) {
    quest.completed = true;
    
    if (questId === 1) {
      persistentState.improvementClicks += 2;
      alert('Quête terminée ! +5 CD (ajoutés au prochain donjon), +2 CA');
    } else if (questId === 2) {
      persistentState.materials['Fer'] = (persistentState.materials['Fer'] || 0) + 2;
      persistentState.improvementClicks += 8;
      alert('Quête terminée ! +8 CA, +2 Fer');
    }
    
    saveGame();
    updateQuestsDisplay();
    updateMainMenuStats();
  }
}